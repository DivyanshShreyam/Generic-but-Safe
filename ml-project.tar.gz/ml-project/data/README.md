# Dataset Download Instructions

All datasets are publicly available. Download them and place CSV files in this `data/` folder.

## 1. Titanic Dataset (Classification)
- **URL**: https://www.kaggle.com/c/titanic/data
- **Files needed**: `train.csv`, `test.csv`
- **Save as**: `data/titanic_train.csv`, `data/titanic_test.csv`

Alternatively, the code will auto-load it via seaborn:
```python
import seaborn as sns
titanic = sns.load_dataset('titanic')
```

## 2. Wine Quality Dataset (Classification)
- **URL**: https://www.kaggle.com/datasets/uciml/red-wine-quality-cortez-et-al-2009
- **File needed**: `winequality-red.csv`
- **Save as**: `data/winequality-red.csv`

UCI Mirror (direct download):
```
https://archive.ics.uci.edu/ml/machine-learning-databases/wine-quality/winequality-red.csv
```

## 3. House Prices – Ames Dataset (Regression)
- **URL**: https://www.kaggle.com/c/house-prices-advanced-regression-techniques/data
- **Files needed**: `train.csv`
- **Save as**: `data/house_prices_train.csv`

## Notes
- The notebooks include fallback data loading using built-in sklearn datasets if Kaggle files are not present.
- A Kaggle API token (`kaggle.json`) can be used to automate downloads:
  ```bash
  pip install kaggle
  kaggle competitions download -c titanic
  kaggle datasets download -d uciml/red-wine-quality-cortez-et-al-2009
  kaggle competitions download -c house-prices-advanced-regression-techniques
  ```
