# Machine Learning Project: Dataset Exploration, Model Development & Evaluation

## Overview

This project demonstrates end-to-end machine learning workflows using **scikit-learn** across three real-world datasets. It covers dataset exploration, preprocessing, model development, hyperparameter tuning, and rigorous evaluation with visualizations.

---

## Project Structure

```
ml-project/
├── README.md
├── requirements.txt
├── notebooks/
│   ├── 01_dataset_exploration.ipynb       # EDA for all three datasets
│   ├── 02_model_development.ipynb         # Model training and validation
│   ├── 03_hyperparameter_tuning.ipynb     # GridSearchCV / RandomizedSearchCV
│   └── 04_results_and_evaluation.ipynb    # Metrics, plots, literature comparison
├── src/
│   ├── __init__.py
│   ├── preprocessing.py                   # Shared preprocessing utilities
│   ├── models.py                          # Model building helpers
│   ├── evaluation.py                      # Metrics and plotting functions
│   └── tuning.py                          # Hyperparameter search wrappers
├── data/
│   └── README.md                          # Dataset download instructions
├── results/
│   └── figures/                           # Saved plots (auto-generated)
└── docs/
    └── literature_review.md               # Prior work citations & summaries
```

---

## Datasets

| # | Dataset | Task | Source |
|---|---------|------|--------|
| 1 | **Titanic** | Binary Classification | [Kaggle](https://www.kaggle.com/c/titanic) |
| 2 | **Wine Quality** | Multi-class Classification | [UCI / Kaggle](https://www.kaggle.com/datasets/uciml/red-wine-quality-cortez-et-al-2009) |
| 3 | **House Prices (Ames)** | Regression | [Kaggle](https://www.kaggle.com/c/house-prices-advanced-regression-techniques) |

---

## Algorithms Used

### Classification (Titanic & Wine Quality)
- Logistic Regression
- k-Nearest Neighbors (kNN)
- Decision Tree
- Naive Bayes (Gaussian)
- Multi-Layer Perceptron (MLP)

### Regression (House Prices)
- Linear Regression
- Decision Tree Regressor
- k-Nearest Neighbors Regressor

---

## Evaluation Metrics

- **Classification**: Accuracy, Precision, Recall, F1-score, ROC-AUC, Confusion Matrix
- **Regression**: MAE, MSE, RMSE, R²

---

## Setup & Installation

```bash
# 1. Clone the repository
git clone https://github.com/your-username/ml-project.git
cd ml-project

# 2. Create a virtual environment
python -m venv venv
source venv/bin/activate        # Linux/macOS
venv\Scripts\activate           # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Download datasets
# See data/README.md for instructions

# 5. Launch Jupyter
jupyter notebook notebooks/
```

---

## Quick Start (Script Mode)

```bash
# Run full pipeline end-to-end
python src/run_pipeline.py
```

---

## Key Results Summary

| Dataset | Best Model | Key Metric |
|---------|-----------|------------|
| Titanic | MLP | Accuracy ≈ 0.82, ROC-AUC ≈ 0.87 |
| Wine Quality | Decision Tree (tuned) | F1-macro ≈ 0.68 |
| House Prices | Linear Regression | R² ≈ 0.85, RMSE ≈ 28,500 |

> See `notebooks/04_results_and_evaluation.ipynb` for full analysis.

---

## Literature Comparison

See [`docs/literature_review.md`](docs/literature_review.md) for citations and comparison with prior work.

---

## License

MIT License — see `LICENSE` file.
