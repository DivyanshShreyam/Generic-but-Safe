"""
evaluation.py
-------------
Metric computation and plotting utilities for both classification
and regression tasks.
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")   # non-interactive backend for script mode
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, ConfusionMatrixDisplay,
    RocCurveDisplay, classification_report,
    mean_absolute_error, mean_squared_error, r2_score,
)

FIGURES_DIR = Path("results/figures")
FIGURES_DIR.mkdir(parents=True, exist_ok=True)


# ══════════════════════════════════════════════
# CLASSIFICATION
# ══════════════════════════════════════════════

def classification_metrics(y_true, y_pred, y_proba=None, average="weighted") -> dict:
    """
    Compute classification metrics.

    Parameters
    ----------
    y_true   : array-like, ground truth labels
    y_pred   : array-like, predicted labels
    y_proba  : array-like or None, predicted probabilities
    average  : averaging strategy for precision/recall/F1

    Returns
    -------
    dict of metric_name → value
    """
    metrics = {
        "accuracy":  accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average=average, zero_division=0),
        "recall":    recall_score(y_true, y_pred, average=average, zero_division=0),
        "f1":        f1_score(y_true, y_pred, average=average, zero_division=0),
    }

    if y_proba is not None:
        classes = np.unique(y_true)
        if len(classes) == 2:
            # Binary: use probability of positive class
            prob_pos = y_proba[:, 1] if y_proba.ndim == 2 else y_proba
            metrics["roc_auc"] = roc_auc_score(y_true, prob_pos)
        else:
            # Multi-class OvR
            metrics["roc_auc"] = roc_auc_score(
                y_true, y_proba, multi_class="ovr", average=average
            )

    return metrics


def print_classification_report(y_true, y_pred, model_name: str = ""):
    """Print sklearn's classification_report."""
    print(f"\n{'─'*50}")
    print(f"Classification Report — {model_name}")
    print(classification_report(y_true, y_pred, zero_division=0))


def plot_confusion_matrix(y_true, y_pred, model_name: str,
                          dataset_name: str, labels=None):
    """Save a confusion matrix heatmap."""
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    disp.plot(ax=ax, colorbar=True, cmap="Blues")
    ax.set_title(f"Confusion Matrix\n{model_name} — {dataset_name}", fontsize=12)
    plt.tight_layout()
    fname = FIGURES_DIR / f"cm_{dataset_name}_{model_name.replace(' ', '_')}.png"
    plt.savefig(fname, dpi=120)
    plt.close()
    print(f"  Saved: {fname}")


def plot_roc_curves(models_dict: dict, X_test, y_test,
                    dataset_name: str, pos_label=1):
    """
    Plot ROC curves for all binary classifiers on one axis.
    Skips models without predict_proba.
    """
    fig, ax = plt.subplots(figsize=(7, 5))
    plotted = False

    for name, model in models_dict.items():
        if not hasattr(model, "predict_proba"):
            continue
        try:
            y_proba = model.predict_proba(X_test)
            classes = model.classes_
            if len(classes) == 2:
                RocCurveDisplay.from_predictions(
                    y_test,
                    y_proba[:, 1],
                    name=name,
                    ax=ax,
                    pos_label=pos_label,
                )
                plotted = True
        except Exception as e:
            print(f"  [WARN] ROC skipped for {name}: {e}")

    if plotted:
        ax.plot([0, 1], [0, 1], "k--", label="Random")
        ax.set_title(f"ROC Curves — {dataset_name}")
        ax.legend(loc="lower right", fontsize=8)
        plt.tight_layout()
        fname = FIGURES_DIR / f"roc_{dataset_name}.png"
        plt.savefig(fname, dpi=120)
        plt.close()
        print(f"  Saved: {fname}")


def plot_metric_comparison(results_df, dataset_name: str, metric: str = "f1"):
    """Bar chart comparing a metric across models."""
    fig, ax = plt.subplots(figsize=(8, 4))
    colors = sns.color_palette("viridis", len(results_df))
    bars = ax.bar(results_df["model"], results_df[metric], color=colors)
    ax.bar_label(bars, fmt="%.3f", padding=3, fontsize=9)
    ax.set_title(f"{metric.upper()} Comparison — {dataset_name}")
    ax.set_ylabel(metric.upper())
    ax.set_ylim(0, 1.1)
    ax.set_xlabel("Model")
    plt.xticks(rotation=15, ha="right")
    plt.tight_layout()
    fname = FIGURES_DIR / f"metric_{dataset_name}_{metric}.png"
    plt.savefig(fname, dpi=120)
    plt.close()
    print(f"  Saved: {fname}")


# ══════════════════════════════════════════════
# REGRESSION
# ══════════════════════════════════════════════

def regression_metrics(y_true, y_pred) -> dict:
    """
    Compute regression metrics.

    Returns
    -------
    dict with mae, mse, rmse, r2
    """
    mae  = mean_absolute_error(y_true, y_pred)
    mse  = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2   = r2_score(y_true, y_pred)
    return {"mae": mae, "mse": mse, "rmse": rmse, "r2": r2}


def plot_residuals(y_true, y_pred, model_name: str, dataset_name: str):
    """Residual plot: predicted vs residuals."""
    residuals = y_true - y_pred
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))

    # Residual vs predicted
    axes[0].scatter(y_pred, residuals, alpha=0.4, s=12, color="steelblue")
    axes[0].axhline(0, color="red", linewidth=1, linestyle="--")
    axes[0].set_xlabel("Predicted (log scale)")
    axes[0].set_ylabel("Residual")
    axes[0].set_title(f"Residual Plot — {model_name}")

    # Distribution of residuals
    axes[1].hist(residuals, bins=40, color="steelblue", edgecolor="white", alpha=0.8)
    axes[1].set_xlabel("Residual")
    axes[1].set_ylabel("Count")
    axes[1].set_title("Residual Distribution")

    plt.suptitle(f"{dataset_name} — {model_name}", fontsize=11)
    plt.tight_layout()
    fname = FIGURES_DIR / f"residuals_{dataset_name}_{model_name.replace(' ', '_')}.png"
    plt.savefig(fname, dpi=120)
    plt.close()
    print(f"  Saved: {fname}")


def plot_prediction_scatter(y_true, y_pred, model_name: str, dataset_name: str):
    """Actual vs Predicted scatter."""
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(y_true, y_pred, alpha=0.4, s=12, color="darkorange")
    lo, hi = min(y_true.min(), y_pred.min()), max(y_true.max(), y_pred.max())
    ax.plot([lo, hi], [lo, hi], "k--", linewidth=1, label="Perfect fit")
    ax.set_xlabel("Actual")
    ax.set_ylabel("Predicted")
    ax.set_title(f"Actual vs Predicted\n{model_name} — {dataset_name}")
    ax.legend()
    plt.tight_layout()
    fname = FIGURES_DIR / f"scatter_{dataset_name}_{model_name.replace(' ', '_')}.png"
    plt.savefig(fname, dpi=120)
    plt.close()
    print(f"  Saved: {fname}")


def plot_regression_comparison(results_df, dataset_name: str, metric: str = "r2"):
    """Bar chart comparing a regression metric across models."""
    fig, ax = plt.subplots(figsize=(7, 4))
    colors = sns.color_palette("magma", len(results_df))
    bars = ax.bar(results_df["model"], results_df[metric], color=colors)
    ax.bar_label(bars, fmt="%.4f", padding=3, fontsize=9)
    ax.set_title(f"{metric.upper()} Comparison — {dataset_name}")
    ax.set_ylabel(metric.upper())
    ax.set_xlabel("Model")
    plt.xticks(rotation=15, ha="right")
    plt.tight_layout()
    fname = FIGURES_DIR / f"metric_{dataset_name}_{metric}.png"
    plt.savefig(fname, dpi=120)
    plt.close()
    print(f"  Saved: {fname}")
