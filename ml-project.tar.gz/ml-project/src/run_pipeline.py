"""
run_pipeline.py
---------------
End-to-end pipeline runner.
Trains, tunes, and evaluates all models across all three datasets,
then prints a consolidated results table.

Usage
-----
    python src/run_pipeline.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from src.preprocessing import (
    load_titanic, preprocess_titanic,
    load_wine_quality, preprocess_wine,
    load_house_prices, preprocess_house_prices,
)
from src.models import get_classification_models, get_regression_models
from src.evaluation import (
    classification_metrics, regression_metrics,
    plot_confusion_matrix, plot_roc_curves,
    plot_metric_comparison, plot_residuals,
    plot_prediction_scatter, plot_regression_comparison,
    print_classification_report,
)
from src.tuning import tune_all_classifiers, tune_all_regressors


def run_classification(dataset_name: str, X_train, X_test, y_train, y_test,
                        tune: bool = True):
    """Train, optionally tune, and evaluate classification models."""
    print(f"\n{'═'*60}")
    print(f"  CLASSIFICATION — {dataset_name}")
    print(f"{'═'*60}")

    models = get_classification_models()

    if tune:
        print("\n[Hyperparameter Tuning]")
        models = tune_all_classifiers(models, X_train, y_train)
    else:
        print("\n[Training (no tuning)]")
        for name, m in models.items():
            # unwrap search objects if already fitted
            estimator = m.best_estimator_ if hasattr(m, "best_estimator_") else m
            estimator.fit(X_train, y_train)
            models[name] = estimator

    # Evaluate
    print("\n[Evaluation]")
    results = []
    for name, search_or_model in models.items():
        model = (search_or_model.best_estimator_
                 if hasattr(search_or_model, "best_estimator_")
                 else search_or_model)

        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test) if hasattr(model, "predict_proba") else None

        m = classification_metrics(y_test, y_pred, y_proba)
        m["model"] = name
        results.append(m)

        print_classification_report(y_test, y_pred, name)
        plot_confusion_matrix(y_test, y_pred, name, dataset_name)

    # ROC curves (binary datasets)
    fitted_models = {
        n: (s.best_estimator_ if hasattr(s, "best_estimator_") else s)
        for n, s in models.items()
    }
    if len(np.unique(y_test)) == 2:
        plot_roc_curves(fitted_models, X_test, y_test, dataset_name)

    df = pd.DataFrame(results)
    print(f"\nSummary — {dataset_name}")
    print(df.to_string(index=False))
    plot_metric_comparison(df, dataset_name, metric="f1")
    plot_metric_comparison(df, dataset_name, metric="accuracy")
    return df


def run_regression(dataset_name: str, X_train, X_test, y_train, y_test,
                   tune: bool = True):
    """Train, optionally tune, and evaluate regression models."""
    print(f"\n{'═'*60}")
    print(f"  REGRESSION — {dataset_name}")
    print(f"{'═'*60}")

    models = get_regression_models()

    if tune:
        print("\n[Hyperparameter Tuning]")
        models = tune_all_regressors(models, X_train, y_train)
    else:
        print("\n[Training (no tuning)]")
        for name, m in models.items():
            m.fit(X_train, y_train)

    print("\n[Evaluation]")
    results = []
    for name, search_or_model in models.items():
        model = (search_or_model.best_estimator_
                 if hasattr(search_or_model, "best_estimator_")
                 else search_or_model)

        y_pred = model.predict(X_test)
        m = regression_metrics(y_test, y_pred)
        m["model"] = name
        results.append(m)
        print(f"\n  {name}: MAE={m['mae']:.4f}  RMSE={m['rmse']:.4f}  R²={m['r2']:.4f}")
        plot_residuals(y_test, y_pred, name, dataset_name)
        plot_prediction_scatter(y_test, y_pred, name, dataset_name)

    df = pd.DataFrame(results)
    print(f"\nSummary — {dataset_name}")
    print(df.to_string(index=False))
    plot_regression_comparison(df, dataset_name, metric="r2")
    plot_regression_comparison(df, dataset_name, metric="rmse")
    return df


def main(tune: bool = True):
    all_results = {}

    # ── Dataset 1: Titanic ─────────────────────
    print("\nLoading Titanic...")
    titanic_df = load_titanic()
    X_tr, X_te, y_tr, y_te, feats, _ = preprocess_titanic(titanic_df)
    print(f"  Shape: {X_tr.shape[0]} train / {X_te.shape[0]} test  |  Features: {feats}")
    all_results["Titanic"] = run_classification("Titanic", X_tr, X_te, y_tr, y_te, tune)

    # ── Dataset 2: Wine Quality ────────────────
    print("\nLoading Wine Quality...")
    wine_df = load_wine_quality()
    X_tr, X_te, y_tr, y_te, feats, _ = preprocess_wine(wine_df)
    print(f"  Shape: {X_tr.shape[0]} train / {X_te.shape[0]} test  |  Features: {feats}")
    all_results["WineQuality"] = run_classification("WineQuality", X_tr, X_te, y_tr, y_te, tune)

    # ── Dataset 3: House Prices ────────────────
    print("\nLoading House Prices...")
    house_df = load_house_prices()
    X_tr, X_te, y_tr, y_te, feats, _ = preprocess_house_prices(house_df)
    print(f"  Shape: {X_tr.shape[0]} train / {X_te.shape[0]} test  |  {len(feats)} features")
    all_results["HousePrices"] = run_regression("HousePrices", X_tr, X_te, y_tr, y_te, tune)

    # ── Consolidated summary ───────────────────
    print(f"\n{'═'*60}")
    print("  CONSOLIDATED RESULTS SUMMARY")
    print(f"{'═'*60}")
    for ds_name, df in all_results.items():
        print(f"\n{ds_name}:")
        print(df.to_string(index=False))

    print("\n✓ Pipeline complete. Figures saved to results/figures/")


if __name__ == "__main__":
    # Pass --no-tune to skip hyperparameter search (faster for testing)
    tune_flag = "--no-tune" not in sys.argv
    main(tune=tune_flag)
