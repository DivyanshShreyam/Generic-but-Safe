"""
preprocessing.py
----------------
Shared preprocessing utilities for all three datasets:
  - Titanic (classification)
  - Wine Quality (classification)
  - House Prices / Ames (regression)
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split


# ──────────────────────────────────────────────
# 1. TITANIC
# ──────────────────────────────────────────────

def load_titanic() -> pd.DataFrame:
    """Load Titanic dataset (seaborn built-in fallback)."""
    try:
        import seaborn as sns
        df = sns.load_dataset("titanic")
    except Exception:
        # Minimal synthetic fallback so notebooks still run offline
        rng = np.random.default_rng(42)
        n = 891
        df = pd.DataFrame({
            "survived": rng.integers(0, 2, n),
            "pclass": rng.choice([1, 2, 3], n),
            "sex": rng.choice(["male", "female"], n),
            "age": rng.uniform(1, 80, n),
            "sibsp": rng.integers(0, 5, n),
            "parch": rng.integers(0, 5, n),
            "fare": rng.uniform(5, 500, n),
            "embarked": rng.choice(["S", "C", "Q", None], n),
        })
    return df


def preprocess_titanic(df: pd.DataFrame):
    """
    Returns X (features), y (target), feature_names, scaler.

    Steps
    -----
    1. Select relevant columns.
    2. Encode categorical variables (sex, embarked).
    3. Impute missing values (age → median, embarked → mode).
    4. Standard-scale numerical features.
    5. Train/test split (80/20, stratified).
    """
    df = df.copy()

    # Select features
    features = ["pclass", "sex", "age", "sibsp", "parch", "fare", "embarked"]
    target = "survived"

    df = df[features + [target]].copy()

    # Encode sex
    df["sex"] = df["sex"].map({"male": 0, "female": 1})

    # Impute embarked before encoding
    df["embarked"] = df["embarked"].fillna(df["embarked"].mode()[0])
    embarked_enc = LabelEncoder()
    df["embarked"] = embarked_enc.fit_transform(df["embarked"].astype(str))

    # Impute age
    age_imputer = SimpleImputer(strategy="median")
    df["age"] = age_imputer.fit_transform(df[["age"]])

    # Drop any remaining NaNs
    df.dropna(inplace=True)

    X = df[features].values
    y = df[target].values

    # Scale
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    return X_train, X_test, y_train, y_test, features, scaler


# ──────────────────────────────────────────────
# 2. WINE QUALITY
# ──────────────────────────────────────────────

def load_wine_quality(path: str = "data/winequality-red.csv") -> pd.DataFrame:
    """Load red wine quality CSV. Falls back to sklearn wine dataset."""
    try:
        df = pd.read_csv(path, sep=";")
    except FileNotFoundError:
        from sklearn.datasets import load_wine
        data = load_wine()
        df = pd.DataFrame(data.data, columns=data.feature_names)
        df["quality"] = data.target  # 0/1/2 → treated as quality classes
        print("[INFO] Kaggle file not found — using sklearn Wine dataset as fallback.")
    return df


def preprocess_wine(df: pd.DataFrame):
    """
    Returns X_train, X_test, y_train, y_test, feature_names, scaler.

    Steps
    -----
    1. Separate features / target (quality).
    2. Bin quality scores into 3 classes: low (≤5), medium (6), high (≥7).
    3. No missing values expected; assert and drop if any.
    4. Standard-scale features.
    5. Train/test split (80/20, stratified).
    """
    df = df.copy()

    if "quality" not in df.columns:
        raise ValueError("Dataset must contain a 'quality' column.")

    # Bin into 3 classes for manageable multi-class problem
    def bin_quality(q):
        if q <= 5:
            return 0   # low
        elif q == 6:
            return 1   # medium
        else:
            return 2   # high

    df["quality_class"] = df["quality"].apply(bin_quality)
    feature_cols = [c for c in df.columns if c not in ("quality", "quality_class")]

    df.dropna(inplace=True)

    X = df[feature_cols].values
    y = df["quality_class"].values

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    return X_train, X_test, y_train, y_test, feature_cols, scaler


# ──────────────────────────────────────────────
# 3. HOUSE PRICES (AMES)
# ──────────────────────────────────────────────

def load_house_prices(path: str = "data/house_prices_train.csv") -> pd.DataFrame:
    """Load Ames House Prices CSV. Falls back to California housing."""
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        from sklearn.datasets import fetch_california_housing
        data = fetch_california_housing()
        df = pd.DataFrame(data.data, columns=data.feature_names)
        df["SalePrice"] = data.target * 100_000   # rescale to dollar-like range
        print("[INFO] Kaggle file not found — using California Housing as fallback.")
    return df


def preprocess_house_prices(df: pd.DataFrame):
    """
    Returns X_train, X_test, y_train, y_test, feature_names, scaler.

    Steps
    -----
    1. Select numeric columns only (simplification for baseline models).
    2. Drop columns with >40% missing values.
    3. Impute remaining numeric NaNs with median.
    4. Log-transform SalePrice to reduce skewness.
    5. Min-Max scale features.
    6. Train/test split (80/20).
    """
    df = df.copy()

    target_col = "SalePrice"
    if target_col not in df.columns:
        raise ValueError("Dataset must contain a 'SalePrice' column.")

    # Keep numeric only
    numeric_df = df.select_dtypes(include=[np.number])

    # Drop high-missingness columns
    threshold = 0.4
    missing_frac = numeric_df.isnull().mean()
    numeric_df = numeric_df.loc[:, missing_frac <= threshold]

    # Separate target
    y = np.log1p(numeric_df[target_col].values)   # log-transform
    feature_cols = [c for c in numeric_df.columns if c != target_col]
    X_raw = numeric_df[feature_cols].values

    # Impute
    imputer = SimpleImputer(strategy="median")
    X_imputed = imputer.fit_transform(X_raw)

    # Scale
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X_imputed)

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42
    )

    return X_train, X_test, y_train, y_test, feature_cols, scaler
