"""
models.py
---------
Factory functions that return configured scikit-learn estimators
for each dataset / task combination.
"""

from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.neural_network import MLPClassifier


# ──────────────────────────────────────────────
# Classification models (Titanic & Wine Quality)
# ──────────────────────────────────────────────

def get_classification_models() -> dict:
    """
    Returns a dict of {name: estimator} for classification tasks.

    Model Justification
    -------------------
    LogisticRegression : Interpretable linear baseline; handles binary/multi-class.
    KNeighborsClassifier: Non-parametric; useful to gauge local similarity structure.
    GaussianNB          : Fast probabilistic model; works well when features are
                          roughly independent (serves as a simple baseline).
    DecisionTreeClassifier: Captures non-linear boundaries; interpretable rules.
    MLPClassifier       : Can model complex interactions; useful when linear models
                          underfit.
    """
    return {
        "Logistic Regression": LogisticRegression(
            max_iter=1000, random_state=42, solver="lbfgs", multi_class="auto"
        ),
        "k-Nearest Neighbors": KNeighborsClassifier(n_neighbors=5),
        "Naive Bayes": GaussianNB(),
        "Decision Tree": DecisionTreeClassifier(random_state=42, max_depth=5),
        "MLP": MLPClassifier(
            hidden_layer_sizes=(100, 50),
            max_iter=500,
            random_state=42,
            early_stopping=True,
        ),
    }


# ──────────────────────────────────────────────
# Regression models (House Prices)
# ──────────────────────────────────────────────

def get_regression_models() -> dict:
    """
    Returns a dict of {name: estimator} for regression tasks.

    Model Justification
    -------------------
    LinearRegression    : Interpretable baseline; assumes linear relationship
                          between features and (log) price.
    KNeighborsRegressor : Non-parametric; captures local neighbourhood effects
                          in housing markets (nearby houses → similar prices).
    DecisionTreeRegressor: Piecewise-constant; can capture non-linear thresholds
                          (e.g. price jumps at certain lot sizes).
    """
    return {
        "Linear Regression": LinearRegression(),
        "k-Nearest Neighbors": KNeighborsRegressor(n_neighbors=5),
        "Decision Tree": DecisionTreeRegressor(random_state=42, max_depth=6),
    }


def train_all(models: dict, X_train, y_train) -> dict:
    """Fit every model in the dict and return the same dict (fitted)."""
    for name, model in models.items():
        print(f"  Training {name}...")
        model.fit(X_train, y_train)
    return models
