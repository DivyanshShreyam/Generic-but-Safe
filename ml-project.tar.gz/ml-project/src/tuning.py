"""
tuning.py
---------
Hyperparameter search wrappers using GridSearchCV and RandomizedSearchCV.
"""

import numpy as np
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV, StratifiedKFold, KFold


# ──────────────────────────────────────────────
# Parameter grids
# ──────────────────────────────────────────────

CLASSIFICATION_PARAM_GRIDS = {
    "Logistic Regression": {
        "C": [0.01, 0.1, 1.0, 10.0, 100.0],
        "solver": ["lbfgs", "liblinear"],
        "penalty": ["l2"],
    },
    "k-Nearest Neighbors": {
        "n_neighbors": [3, 5, 7, 11, 15],
        "weights": ["uniform", "distance"],
        "metric": ["euclidean", "manhattan"],
    },
    "Naive Bayes": {
        "var_smoothing": np.logspace(-12, -6, 7),
    },
    "Decision Tree": {
        "max_depth": [3, 5, 7, 10, None],
        "min_samples_split": [2, 5, 10],
        "criterion": ["gini", "entropy"],
    },
    "MLP": {
        "hidden_layer_sizes": [(64,), (100,), (100, 50), (128, 64)],
        "alpha": [1e-4, 1e-3, 1e-2],
        "learning_rate_init": [0.001, 0.01],
    },
}

REGRESSION_PARAM_GRIDS = {
    "Linear Regression": {},          # no hyperparameters to tune
    "k-Nearest Neighbors": {
        "n_neighbors": [3, 5, 7, 11, 15],
        "weights": ["uniform", "distance"],
    },
    "Decision Tree": {
        "max_depth": [3, 5, 7, 10, None],
        "min_samples_split": [2, 5, 10],
        "min_samples_leaf": [1, 2, 4],
    },
}


# ──────────────────────────────────────────────
# Search functions
# ──────────────────────────────────────────────

def grid_search_classification(model, model_name: str,
                                X_train, y_train, cv: int = 5) -> GridSearchCV:
    """
    Run GridSearchCV for a classification model.

    Parameters
    ----------
    model      : unfitted sklearn estimator
    model_name : key in CLASSIFICATION_PARAM_GRIDS
    X_train    : training features
    y_train    : training labels
    cv         : number of cross-validation folds

    Returns
    -------
    Fitted GridSearchCV object
    """
    param_grid = CLASSIFICATION_PARAM_GRIDS.get(model_name, {})
    if not param_grid:
        print(f"  [INFO] No param grid for {model_name}; skipping tuning.")
        model.fit(X_train, y_train)
        return model

    cv_strategy = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
    gs = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        cv=cv_strategy,
        scoring="f1_weighted",
        n_jobs=-1,
        verbose=0,
        refit=True,
    )
    gs.fit(X_train, y_train)
    print(f"  Best params ({model_name}): {gs.best_params_}")
    print(f"  Best CV F1-weighted:        {gs.best_score_:.4f}")
    return gs


def randomized_search_classification(model, model_name: str,
                                      X_train, y_train,
                                      cv: int = 5, n_iter: int = 20) -> RandomizedSearchCV:
    """
    Run RandomizedSearchCV (useful for larger search spaces, e.g. MLP).
    """
    param_grid = CLASSIFICATION_PARAM_GRIDS.get(model_name, {})
    if not param_grid:
        print(f"  [INFO] No param grid for {model_name}; skipping tuning.")
        model.fit(X_train, y_train)
        return model

    cv_strategy = StratifiedKFold(n_splits=cv, shuffle=True, random_state=42)
    rs = RandomizedSearchCV(
        estimator=model,
        param_distributions=param_grid,
        n_iter=n_iter,
        cv=cv_strategy,
        scoring="f1_weighted",
        n_jobs=-1,
        random_state=42,
        verbose=0,
        refit=True,
    )
    rs.fit(X_train, y_train)
    print(f"  Best params ({model_name}): {rs.best_params_}")
    print(f"  Best CV F1-weighted:        {rs.best_score_:.4f}")
    return rs


def grid_search_regression(model, model_name: str,
                            X_train, y_train, cv: int = 5) -> GridSearchCV:
    """
    Run GridSearchCV for a regression model.
    """
    param_grid = REGRESSION_PARAM_GRIDS.get(model_name, {})
    if not param_grid:
        print(f"  [INFO] No param grid for {model_name}; fitting directly.")
        model.fit(X_train, y_train)
        return model

    cv_strategy = KFold(n_splits=cv, shuffle=True, random_state=42)
    gs = GridSearchCV(
        estimator=model,
        param_grid=param_grid,
        cv=cv_strategy,
        scoring="r2",
        n_jobs=-1,
        verbose=0,
        refit=True,
    )
    gs.fit(X_train, y_train)
    print(f"  Best params ({model_name}): {gs.best_params_}")
    print(f"  Best CV R²:                 {gs.best_score_:.4f}")
    return gs


def tune_all_classifiers(models: dict, X_train, y_train,
                          use_random: bool = False) -> dict:
    """
    Tune every classifier in `models` dict.
    MLP uses RandomizedSearch by default; others use GridSearch.
    """
    tuned = {}
    for name, model in models.items():
        print(f"\nTuning {name}...")
        if use_random or name == "MLP":
            result = randomized_search_classification(model, name, X_train, y_train)
        else:
            result = grid_search_classification(model, name, X_train, y_train)
        tuned[name] = result
    return tuned


def tune_all_regressors(models: dict, X_train, y_train) -> dict:
    """Tune every regressor in `models` dict."""
    tuned = {}
    for name, model in models.items():
        print(f"\nTuning {name}...")
        tuned[name] = grid_search_regression(model, name, X_train, y_train)
    return tuned
