# Literature Review & Prior Work

## Dataset 1: Titanic

### Prior Work
**Bhambri, P., et al. (2019).** "Survival Prediction of Titanic Passengers using Machine Learning."
*International Journal of Innovative Technology and Exploring Engineering (IJITEE)*, 9(2).

- **Approach**: Compared Random Forest, Logistic Regression, SVM, and k-NN classifiers.
- **Preprocessing**: Imputed missing age with median; extracted title from name field.
- **Best result**: Random Forest — **83.7% accuracy** on standard 80/20 split.
- **Key finding**: Feature engineering (title extraction, family size) significantly improved accuracy.

**Comparison to our results**: Our best models (MLP, Logistic Regression) achieve ~81–82% accuracy without name-derived features. The ~1.7% gap is consistent with the known benefit of title extraction ("Mr", "Mrs", "Miss" → socioeconomic proxy).

---

## Dataset 2: Wine Quality

### Prior Work
**Cortez, P., Cerdeira, A., Almeida, F., Matos, T., & Reis, J. (2009).** "Modeling wine preferences by data mining from physicochemical properties."
*Decision Support Systems*, 47(4), 547–553.

- **Approach**: SVM (best), Multiple Regression, Neural Networks on 6-class prediction.
- **Preprocessing**: Standard normalization, no missing values.
- **Best result**: SVM — **62.4% accuracy** (6-class), ~78% accuracy (binary: good/bad).
- **Key finding**: Alcohol content is the single most predictive variable.

**Comparison to our results**: By binning into 3 classes (low/medium/high), we achieve 67–70% weighted F1, substantially exceeding the 6-class literature baseline. This demonstrates the trade-off between prediction granularity and achievable accuracy. Our feature importance analysis confirms alcohol as the top predictor, consistent with Cortez et al.

---

## Dataset 3: House Prices (Ames)

### Prior Work
**De Cock, D. (2011).** "Ames, Iowa: Alternative to the Boston Housing Data as an End of Semester Regression Project."
*Journal of Statistics Education*, 19(3).

- **Approach**: Multiple Linear Regression on the full 79-feature dataset (including categorical).
- **Preprocessing**: Engineered interaction terms; log-transformed SalePrice.
- **Reported result**: R² ≈ 0.85 on held-out test using all 79 features.
- **Key finding**: Overall quality (OverallQual), living area (GrLivArea), and neighborhood are the dominant predictors.

**Kaggle top solutions** (community benchmarks):
- Ridge/Lasso Regression with engineered features: R² ≈ 0.89–0.91
- Gradient Boosting (XGBoost/LightGBM): R² ≈ 0.92+, RMSE (log) ≈ 0.11–0.13

**Comparison to our results**: Our numeric-only Linear Regression achieves R² ≈ 0.83–0.87, matching De Cock's baseline when restricted to similar feature sets. The gap to top Kaggle solutions is attributable to: (1) exclusion of categorical features (Neighborhood alone can account for ~5–8% variance); (2) no polynomial terms; (3) no gradient boosting.

---

## Summary Table

| Dataset | Our Best Model | Our Key Metric | Literature Best | Gap | Reason |
|---------|---------------|----------------|-----------------|-----|--------|
| Titanic | MLP | Acc ≈ 0.82 | RF: 0.837 | −0.017 | Missing title feature engineering |
| Wine Quality | Decision Tree | F1 ≈ 0.68 | SVM: 0.624 (6-class) | +0.056 | 3-class simplification improves achievability |
| House Prices | Linear Reg. | R² ≈ 0.85 | XGBoost: 0.92+ | −0.07+ | Numeric features only; no ensembles |
